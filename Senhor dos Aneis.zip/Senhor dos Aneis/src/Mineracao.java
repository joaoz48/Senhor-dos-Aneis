public interface Mineracao {
    public void minerar();
}
