public interface Cura {
    public void curar();
}
