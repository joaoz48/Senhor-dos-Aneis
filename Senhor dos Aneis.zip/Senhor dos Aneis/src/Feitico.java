public interface Feitico {
    public void lancaFeitico();
}
