public class Arma {
    private String nomeArma;
    private boolean magica;

    public String getNomeArma() {
        return nomeArma;
    }

    public void setNomeArma(String nomeArma) {
        this.nomeArma = nomeArma;
    }

    public boolean isMagica() {
        return magica;
    }

    public void setMagica(boolean magica) {
        this.magica = magica;
    }
}
